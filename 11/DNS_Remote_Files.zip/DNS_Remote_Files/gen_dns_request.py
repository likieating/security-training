#!/bin/env python3

from scapy.all import *

# The source IP can be any address. 
# However, if the target local DNS server is configured to only respond
# to requests from local machines, this source IP should be in the 
# same network as the destination. 
srcIP = '10.0.2.20'  
dstIP = '10.9.0.53'  # Local DNS Server

ip  = IP (dst=dstIP, src=srcIP)
udp = UDP(dport=53, sport=50945, chksum=0)

# The C code will modify the qname field
Qdsec = DNSQR(qname='aaaaa.example.com')

dns   = DNS(id=0xAAAA, qr=0, qdcount=1, qd=****)

pkt = ip/udp/dns
with open('ip_req.bin', 'wb') as f:
    f.write(bytes(pkt))

